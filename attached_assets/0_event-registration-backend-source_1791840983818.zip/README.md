# Event registration API handoff

This bundle contains the Laravel code and schema migrations relevant to mobile event joining and invitation acceptance. It excludes `.env` files, credentials, and production data.

## Mobile endpoints

The routes are inside Laravel's `/api/v1` prefix and the `auth:sanctum` middleware group.

- `POST /api/v1/events/join` — joins by event code. JSON accepts `code` or legacy `event_code`.
- `POST /api/v1/app/events/join` — alias for the same join handler.
- `POST /api/v1/app/events/join-by-code` — alias accepting `code`.
- `POST /api/v1/app/invites/accept` — accepts an invitation using JSON `{ "token": "..." }`.
- `GET /api/v1/app/events/{eventId}/my-role` — returns the caller's event membership role/status.

An event's `event_code` and an invitation's `invites.token` are separate identifiers. Joining by event code creates a membership and attempts an automatic check-in. Accepting an invite uses the invite token and creates a confirmed membership.

## Included source

- `routes/api.php`
- Join and invite controllers
- Event, invite, membership, and check-in models
- Migrations that define the event, membership, invite, and check-in tables
- `SponsorRepService`, used to determine the event membership role

