<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\V1\AuthController;
use App\Http\Controllers\Api\V1\TenantController;
use App\Http\Controllers\Api\V1\EventController;
use App\Http\Controllers\Api\V1\ModuleController;
use App\Http\Controllers\Api\V1\EventJoinController;
use App\Http\Controllers\Api\V1\InviteController;
use App\Http\Controllers\Api\V1\EventMemberController;
use App\Http\Controllers\Api\V1\CredibilityController;
use App\Http\Controllers\Api\V1\AudienceController;
use App\Http\Controllers\Api\V1\EventAudienceController;
use App\Http\Controllers\Api\V1\AudienceImportController;
use App\Http\Controllers\Api\V1\BadgeController;
use App\Http\Controllers\Api\V1\EventCheckinController;
use App\Http\Controllers\Api\V1\EventCompanyController;
use App\Http\Controllers\Api\V1\EventSurveyController;
use App\Http\Controllers\Api\V1\EventPollController;
use App\Http\Controllers\Api\V1\EventVideoFeedController;
use App\Http\Controllers\Api\V1\MobileEventVideoFeedController;
use App\Http\Controllers\Api\V1\TagController;
use App\Http\Controllers\Api\V1\CompanyController;
use App\Http\Controllers\Api\V1\IndustryController;
use App\Http\Controllers\Api\V1\ModeratorController;
use App\Http\Controllers\Api\V1\TestDataController;
use App\Http\Controllers\Api\V1\EventAgendaController;
use App\Http\Controllers\Api\V1\AgendaTemplateController;
use App\Http\Controllers\Api\V1\EventLiveStatusController;
use App\Http\Controllers\Api\V1\EventStreamController;
use App\Http\Controllers\Api\V1\EventGamificationController;
use App\Http\Controllers\Api\V1\EventReportingController;
use App\Http\Controllers\Api\V1\LeadScanController;
use App\Http\Controllers\Api\V1\SurveySubmitController;
use App\Http\Controllers\Api\V1\PollVoteController;
use App\Http\Controllers\Api\V1\MobileController;
use App\Http\Controllers\Api\V1\MobileNotificationController;
use App\Http\Controllers\Api\V1\MobileEventController;
use App\Http\Controllers\Api\V1\MobileVideoFeedController;
use App\Http\Controllers\Api\V1\MobileAccessController;
use App\Http\Controllers\Api\V1\OtpController;
use App\Http\Controllers\Api\V1\AdminController;
use App\Http\Controllers\Api\V1\GlobalVideoFeedController;
use App\Http\Controllers\Api\V1\ReaderDocumentController;
use App\Http\Controllers\Api\V1\MobileReaderController;
use App\Http\Controllers\Api\V1\ArticleAnalyticsController;
use App\Http\Controllers\Api\V1\AdminArticleAnalyticsController;
use App\Http\Controllers\Api\V1\AdminContentAnalyticsController;
use App\Http\Controllers\Api\V1\VideoAnalyticsController;
use App\Http\Controllers\Api\V1\EventGiveawayController;
use App\Http\Controllers\Api\V1\MobileGiveawayController;
use App\Http\Controllers\Api\V1\MobileClientLogController;
use App\Http\Controllers\Api\V1\TenantConfigController;
use App\Http\Controllers\Api\V1\EventManagerController;
use App\Http\Controllers\Api\V1\ExportController;
use App\Http\Controllers\Api\Superadmin\ClientController as SuperadminClientController;
use App\Http\Controllers\Api\Superadmin\ModuleController as SuperadminModuleController;
use App\Http\Controllers\Api\Superadmin\PlanController as SuperadminPlanController;
use App\Http\Controllers\Api\Superadmin\SubscriptionController as SuperadminSubscriptionController;
use App\Http\Controllers\Api\Superadmin\InvoiceController as SuperadminInvoiceController;

Route::prefix('v1')->group(function () {

    // ──────────────────────────────────────────────────────────────────────────
    // Public routes
    // ──────────────────────────────────────────────────────────────────────────

    Route::middleware('throttle:60,1')->group(function () {
        Route::get('/health', function () {
            // Check Redis reachability without blocking the response on failure.
            // The queue and cache do NOT currently use Redis (both use the
            // database/file drivers), so a Redis outage does not affect API
            // traffic.  We still report the status so monitoring tools have
            // a single endpoint to poll.
            //
            // The 'health_check' Redis connection has a 150 ms connect timeout
            // (REDIS_HEALTH_TIMEOUT env var, default 0.15 s) and max_retries=0
            // so this endpoint always responds within 200 ms even when Redis is
            // completely unreachable — giving uptime monitors a fast signal.
            $redisStatus = 'ok';
            $redisError  = null;

            try {
                $response = \Illuminate\Support\Facades\Redis::connection('health_check')->ping();
                $ok = ($response === true || (string) $response === 'PONG');
                if (!$ok) {
                    $redisStatus = 'degraded';
                    $redisError  = 'Unexpected PING response: ' . json_encode($response);
                }
            } catch (\Throwable $e) {
                $redisStatus = 'unreachable';
                $redisError  = app()->isProduction() ? 'Connection failed' : $e->getMessage();

                \Illuminate\Support\Facades\Log::warning('redis.unreachable', [
                    'error' => $e->getMessage(),
                    'class' => get_class($e),
                    'via'   => 'health_endpoint',
                    'at'    => now()->toIso8601String(),
                ]);
            }

            // Overall status is 'ok' only when all components are healthy.
            // Individual component failures are surfaced in 'components' so
            // operators can see exactly what is degraded.
            $overallOk = ($redisStatus === 'ok');

            // OPcache stats — gracefully degrade when the extension is absent
            // (e.g. CLI-only environments where opcache is not loaded).
            $opcacheEnabled  = function_exists('opcache_get_status');
            $opcacheHitRate  = null;
            if ($opcacheEnabled) {
                $ocStatus = @opcache_get_status(false);
                if (is_array($ocStatus)) {
                    $opcacheEnabled = (bool) ($ocStatus['opcache_enabled'] ?? false);
                    $stats = $ocStatus['opcache_statistics'] ?? [];
                    $hits   = (int) ($stats['hits']   ?? 0);
                    $misses = (int) ($stats['misses']  ?? 0);
                    $total  = $hits + $misses;
                    $opcacheHitRate = $total > 0
                        ? round(($hits / $total) * 100, 1)
                        : null;
                } else {
                    $opcacheEnabled = false;
                }
            }

            // PHP_CLI_SERVER_WORKERS is set in the run command; expose it so
            // ops can confirm the worker count without shell access.
            $phpWorkers = getenv('PHP_CLI_SERVER_WORKERS');
            $phpWorkers = ($phpWorkers !== false && $phpWorkers !== '')
                ? (int) $phpWorkers
                : 'unknown';

            $payload = [
                'status'    => $overallOk ? 'ok' : 'degraded',
                'version'   => 'v1',
                'timestamp' => now()->toIso8601String(),
                'components' => [
                    'redis' => array_filter([
                        'status' => $redisStatus,
                        'error'  => $redisError,
                    ], fn ($v) => $v !== null),
                ],
                'opcache' => array_filter([
                    'enabled'  => $opcacheEnabled,
                    'hit_rate' => $opcacheHitRate,
                ], fn ($v) => $v !== null),
                'php_workers' => $phpWorkers,
            ];

            // Return 200 even when degraded so load-balancer health checks
            // that hard-fail on non-2xx keep routing traffic (the API itself
            // is still operational without Redis today).
            return response()->json($payload);
        });

        Route::post('/auth/login', [AuthController::class, 'login']);
        Route::post('/auth/register', [AuthController::class, 'register']);
        Route::post('/auth/forgot-password', [AuthController::class, 'forgotPassword']);
        Route::post('/auth/reset-password', [AuthController::class, 'resetPassword']);

        // ── OTP routes (passwordless login / phone+email verify) ──────────────
        Route::post('/auth/send-otp', [OtpController::class, 'send']);
        Route::post('/auth/verify-otp', [OtpController::class, 'verify']);

        // ── Mobile client-side log (fire-and-forget from apiClient catch block) ─
        // Captures failures that never reached the server (timeout, offline, etc.)
        // Auth token is accepted if present but not required.
        Route::post('/mobile/client-logs', [MobileClientLogController::class, 'store']);

        // ── CXO Feeds tab — pre-login content (no auth required) ─────────────
        // Tenant is resolved from X-Tenant-ID header; no token needed.
        // These power the global Podcast (video-feeds) and Article (reader)
        // tabs visible on the welcome/discovery screen before login.
        // NOTE: /categories must be before /{feedId} to avoid ambiguous routing.
        Route::get('/mobile/video-feeds/categories', [MobileVideoFeedController::class, 'categories']);
        Route::get('/mobile/video-feeds', [MobileVideoFeedController::class, 'index']);
        Route::get('/mobile/video-feeds/{feedId}', [MobileVideoFeedController::class, 'show']);

        Route::get('/mobile/reader/categories', [MobileReaderController::class, 'categories']);
        Route::get('/mobile/reader/documents', [MobileReaderController::class, 'index']);
        Route::get('/mobile/reader/documents/{documentId}', [MobileReaderController::class, 'show']);
    });

    // ──────────────────────────────────────────────────────────────────────────
    // Authenticated routes
    // ──────────────────────────────────────────────────────────────────────────

    Route::middleware(['auth:sanctum', 'throttle:300,1'])->group(function () {

        // ── Async exports — poll endpoint only ───────────────────────────────
        // Async exports are enqueued via the event-scoped download routes with
        // ?async=1. This poll route lets clients check status and retrieve the
        // download URL; it enforces user-ownership before returning anything.
        Route::get('/exports/{exportId}', [ExportController::class, 'show']);

        // Auth & session management
        Route::get('/me', [AuthController::class, 'me']);
        Route::get('/me/context', [AuthController::class, 'context']);
        Route::get('/me/badge-qr', [BadgeController::class, 'myQr']);
        Route::get('/me/badge', [BadgeController::class, 'myBadge']);

        // ── Mobile: profile endpoints ─────────────────────────────────────────
        Route::get('/me/profile', [MobileController::class, 'profile']);
        Route::put('/me/profile', [MobileController::class, 'updateProfile']);
        Route::post('/me/profile', [MobileController::class, 'updateProfile']);
        Route::post('/me/profile/avatar', [MobileController::class, 'uploadAvatar']);
        Route::put('/me/profile/password', [MobileController::class, 'updatePassword']);

        // ── Mobile: push tokens ───────────────────────────────────────────────
        Route::post('/me/push-tokens', [MobileNotificationController::class, 'registerToken']);
        Route::delete('/me/push-tokens/{token}', [MobileNotificationController::class, 'removeToken']);

        // ── Mobile: notification feed ─────────────────────────────────────────
        Route::get('/me/notifications', [MobileNotificationController::class, 'index']);
        Route::get('/me/notifications/unread-count', [MobileNotificationController::class, 'unreadCount']);
        Route::post('/me/notifications/read-all', [MobileNotificationController::class, 'markAllRead']);
        Route::post('/me/notifications/{id}/read', [MobileNotificationController::class, 'markRead']);

        // ── Versioned Expo push notification contract ─────────────────────────
        Route::middleware('tenant.require')->group(function () {
            Route::post('/push/devices', [\App\Http\Controllers\Api\V1\PushDeviceController::class, 'store']);
            Route::patch('/push/devices/{installationUuid}/permission', [\App\Http\Controllers\Api\V1\PushDeviceController::class, 'updatePermission']);
            Route::delete('/push/devices/{installationUuid}', [\App\Http\Controllers\Api\V1\PushDeviceController::class, 'destroy']);
            Route::get('/notifications', [\App\Http\Controllers\Api\V1\NotificationCenterController::class, 'index']);
            Route::get('/notifications/unread-count', [\App\Http\Controllers\Api\V1\NotificationCenterController::class, 'unreadCount']);
            Route::post('/notifications/read-all', [\App\Http\Controllers\Api\V1\NotificationCenterController::class, 'markAllRead']);
            Route::post('/notifications/{notificationId}/read', [\App\Http\Controllers\Api\V1\NotificationCenterController::class, 'markRead']);
            Route::post('/notifications/{notificationId}/opened', [\App\Http\Controllers\Api\V1\NotificationCenterController::class, 'opened']);
            Route::get('/notification-preferences', [\App\Http\Controllers\Api\V1\NotificationCenterController::class, 'preferences']);
            Route::patch('/notification-preferences/{eventId}', [\App\Http\Controllers\Api\V1\NotificationCenterController::class, 'updatePreferences']);

            Route::get('/notification-campaigns', [\App\Http\Controllers\Api\V1\NotificationCampaignController::class, 'index']);
            Route::post('/events/{eventId}/notification-campaigns', [\App\Http\Controllers\Api\V1\NotificationCampaignController::class, 'store']);
            Route::put('/notification-campaigns/{campaignUuid}', [\App\Http\Controllers\Api\V1\NotificationCampaignController::class, 'update']);
            Route::post('/notification-campaigns/{campaignUuid}/estimate', [\App\Http\Controllers\Api\V1\NotificationCampaignController::class, 'estimate']);
            Route::post('/notification-campaigns/{campaignUuid}/send', [\App\Http\Controllers\Api\V1\NotificationCampaignController::class, 'send']);
            Route::post('/notification-campaigns/{campaignUuid}/schedule', [\App\Http\Controllers\Api\V1\NotificationCampaignController::class, 'schedule']);
            Route::post('/notification-campaigns/{campaignUuid}/cancel', [\App\Http\Controllers\Api\V1\NotificationCampaignController::class, 'cancel']);
            Route::post('/notification-campaigns/{campaignUuid}/duplicate', [\App\Http\Controllers\Api\V1\NotificationCampaignController::class, 'duplicate']);
            Route::post('/notification-campaigns/{campaignUuid}/test', [\App\Http\Controllers\Api\V1\NotificationCampaignController::class, 'test']);
        });

        // ── Mobile: my events (no event-member check needed) ──────────────────
        Route::get('/mobile/my-events', [MobileController::class, 'myEvents']);

        // ── Mobile: article analytics ingestion ────────────────────────────
        // (video-feeds + reader GET routes are in the public group — pre-login)
        Route::post('/mobile/reader/analytics/event', [ArticleAnalyticsController::class, 'recordEvent']);
        Route::post('/mobile/reader/analytics/read-session', [ArticleAnalyticsController::class, 'recordReadSession']);
        Route::post('/mobile/video/analytics/event', [VideoAnalyticsController::class, 'recordEvent']);

        // ── Mobile: event access check (must be outside event.member guard) ───
        // Call this BEFORE navigating into any event to check membership.
        // Always returns 200; check `data.is_member` in the response.
        Route::get('/events/{eventId}/access', [MobileAccessController::class, 'check']);

        // ── Mobile: join event by code (outside guard — user isn't a member yet)
        // Accepts body: { "event_code": "XXXXX" } or { "code": "XXXXX" }
        Route::post('/events/join', [EventJoinController::class, 'join']);

        // ── Mobile: all event-scoped routes (requires active event membership) ─
        // The event.member middleware returns HTTP 403 NOT_EVENT_MEMBER when the
        // authenticated user has no active membership for {eventId}.
        Route::middleware('event.member')->group(function () {

            // Home screen & attendee directory
            Route::get('/events/{eventId}/home', [MobileController::class, 'eventHome']);
            Route::get('/events/{eventId}/preload', [MobileController::class, 'preload']);
            Route::get('/events/{eventId}/attendees', [MobileController::class, 'attendees']);
            Route::get('/events/{eventId}/attendees/{userId}', [MobileController::class, 'attendeeProfile']);
            Route::patch('/events/{eventId}/networking-opt-in', [MobileController::class, 'updateNetworkingOptIn']);

            // Networking: leads & meetings
            Route::get('/events/{eventId}/my-leads', [MobileController::class, 'myLeads']);
            Route::get('/events/{eventId}/my-meetings', [MobileController::class, 'myMeetings']);
            Route::patch('/events/{eventId}/my-meetings/{meetingId}', [MobileController::class, 'respondToMeeting']);
            Route::post('/events/{eventId}/my-meetings/{meetingId}/complete', [MobileController::class, 'completeMeeting']);
            Route::post('/events/{eventId}/meetings', [MobileEventController::class, 'requestMeeting']);
            Route::patch('/events/{eventId}/meetings/{meetingId}/respond', [MobileEventController::class, 'respondToMeeting']);

            // Content feed
            Route::get('/events/{eventId}/feed', [MobileEventController::class, 'feed']);

            // Gamification
            Route::get('/events/{eventId}/leaderboard', [MobileEventController::class, 'leaderboard'])->middleware('cache.public');
            Route::get('/events/{eventId}/my-rank', [MobileEventController::class, 'myRank']);

            // Challenges — list + claim (mobile, no tenant context required)
            Route::get('/events/{eventId}/gamification/challenges', [EventGamificationController::class, 'getChallenges']);
            Route::post('/events/{eventId}/gamification/challenges/{challengeId}/claim', [EventGamificationController::class, 'claimChallengePoints']);

            // Polls — responses include per-user has_voted/is_voted state; do NOT cache publicly.
            Route::get('/events/{eventId}/mobile-polls', [MobileEventController::class, 'polls']);
            Route::get('/events/{eventId}/mobile-polls/{pollId}', [MobileEventController::class, 'pollShow']);
            Route::post('/events/{eventId}/mobile-polls/{pollId}/vote', [MobileEventController::class, 'pollVote']);

            // Surveys — responses include per-user has_responded state; do NOT cache publicly.
            Route::get('/events/{eventId}/mobile-surveys', [MobileEventController::class, 'surveys']);
            Route::get('/events/{eventId}/mobile-surveys/{surveyId}', [MobileEventController::class, 'surveyShow']);
            Route::post('/events/{eventId}/mobile-surveys/{surveyId}/submit', [MobileEventController::class, 'surveySubmit']);

            // Agenda
            Route::get('/events/{eventId}/mobile-agenda', [MobileEventController::class, 'agenda'])->middleware('cache.public');

            // Event-scoped video feed (legacy mixed feed — event + global)
            Route::get('/events/{eventId}/videos', [MobileEventController::class, 'videos'])->middleware('cache.public');
            Route::post('/events/{eventId}/videos/{videoId}/view', [MobileEventController::class, 'recordVideoView']);

            // Event-scoped video feeds (dedicated — only event's own published feeds)
            Route::get('/events/{eventId}/event-video-feeds', [MobileEventVideoFeedController::class, 'index']);
            Route::get('/events/{eventId}/event-video-feeds/{feedId}', [MobileEventVideoFeedController::class, 'show']);
            Route::post('/events/{eventId}/event-video-feeds/{feedId}/view', [MobileEventVideoFeedController::class, 'recordView']);

            // Check-in & lead scan
            Route::post('/events/{eventId}/self-check-in', [MobileEventController::class, 'selfCheckIn']);
            Route::post('/events/{eventId}/scan', [MobileEventController::class, 'scan']);
            // Mobile-client lead-scan contract:
            //   POST  { code, name?, company?, title?, notes?, tags?, priority? }
            //   PATCH { notes?, tags?, priority? }  (scanner-only edit)
            Route::post('/events/{eventId}/leads/scan', [MobileEventController::class, 'leadsScan']);
            Route::get('/events/{eventId}/leads/{scanId}', [MobileEventController::class, 'leadsShow'])->whereNumber('scanId');
            Route::patch('/events/{eventId}/leads/{scanId}', [MobileEventController::class, 'leadsUpdate'])->whereNumber('scanId');

            // Sponsor / company reviews (legacy single-review endpoints)
            Route::get('/events/{eventId}/companies/{companyId}/my-review', [MobileEventController::class, 'myCompanyReview']);
            Route::post('/events/{eventId}/companies/{companyId}/review', [MobileEventController::class, 'submitCompanyReview']);

            // Sponsor / company reviews (mobile public shape: list, upsert, delete-mine, export)
            Route::get('/events/{eventId}/companies/{companyId}/reviews/export', [MobileEventController::class, 'exportCompanyReviews']);
            Route::delete('/events/{eventId}/companies/{companyId}/reviews/me', [MobileEventController::class, 'deleteMyCompanyReview']);
            Route::get('/events/{eventId}/companies/{companyId}/reviews', [MobileEventController::class, 'listCompanyReviews']);
            Route::post('/events/{eventId}/companies/{companyId}/reviews', [MobileEventController::class, 'createCompanyReview']);

            // Giveaways (attendee)
            Route::get('/events/{eventId}/mobile-giveaways', [MobileGiveawayController::class, 'index']);
            Route::post('/events/{eventId}/mobile-giveaways/{giveawayId}/enter', [MobileGiveawayController::class, 'enter']);
            // Sponsor-rep / admin "lucky draw" surface — view entry pool
            // and trigger the random draw from the mobile sponsor app.
            // Authorization is enforced inside the controller (must
            // represent the giveaway's company OR be an org/tenant admin).
            Route::get('/events/{eventId}/mobile-giveaways/{giveawayId}/entries', [MobileGiveawayController::class, 'entries']);
            Route::post('/events/{eventId}/mobile-giveaways/{giveawayId}/draw', [MobileGiveawayController::class, 'draw']);

        }); // end event.member group

        Route::post('/auth/logout', [AuthController::class, 'logout']);
        Route::post('/auth/refresh', [AuthController::class, 'refresh']);
        Route::get('/auth/devices', [AuthController::class, 'devices']);
        Route::delete('/auth/devices/{tokenId}', [AuthController::class, 'revokeDevice']);

        Route::get('/modules', [ModuleController::class, 'index']);
        Route::get('/modules/catalog', [ModuleController::class, 'catalog']);

        Route::prefix('app')->group(function () {
            Route::post('/events/join', [EventJoinController::class, 'join']);
            Route::post('/events/join-by-code', [EventJoinController::class, 'joinByCode']);
            Route::get('/events/{eventId}/my-role', [EventJoinController::class, 'myRole']);
            Route::post('/invites/accept', [InviteController::class, 'accept']);
        });

        Route::middleware('role:superadmin')->group(function () {
            Route::apiResource('tenants', TenantController::class);
            Route::get('/tenants/{tenant}/entitlements', [TenantController::class, 'getEntitlements']);
            Route::post('/tenants/{tenant}/entitlements', [TenantController::class, 'updateEntitlements']);
            Route::post('/tenants/{tenant}/subscription', [TenantController::class, 'updateSubscription']);
            Route::get('/tenants/{tenantId}/users/{userId}/credibility', [CredibilityController::class, 'show']);
        });

        Route::get('/industries', [IndustryController::class, 'index']);
        Route::post('/industries', [IndustryController::class, 'store']);

        // Interest tags — search/autocomplete
        Route::get('/tags', [TagController::class, 'index']);

        Route::prefix('superadmin')->middleware('superadmin')->group(function () {
            Route::get('/clients', [SuperadminClientController::class, 'index']);
            Route::post('/clients', [SuperadminClientController::class, 'store']);
            Route::get('/clients/{clientId}', [SuperadminClientController::class, 'show']);
            Route::put('/clients/{clientId}', [SuperadminClientController::class, 'update']);
            Route::post('/clients/{clientId}/disable', [SuperadminClientController::class, 'disable']);
            Route::post('/clients/{clientId}/enable', [SuperadminClientController::class, 'enable']);

            Route::get('/modules', [SuperadminModuleController::class, 'index']);
            Route::post('/modules', [SuperadminModuleController::class, 'store']);

            Route::get('/plans', [SuperadminPlanController::class, 'index']);
            Route::post('/plans', [SuperadminPlanController::class, 'store']);
            Route::put('/plans/{planId}/modules', [SuperadminPlanController::class, 'updateModules']);

            Route::get('/clients/{clientId}/modules', [SuperadminModuleController::class, 'clientModules']);
            Route::put('/clients/{clientId}/modules', [SuperadminModuleController::class, 'updateClientModules']);
            Route::post('/clients/{clientId}/modules/reset', [SuperadminModuleController::class, 'resetClientModules']);

            Route::get('/clients/{clientId}/subscription', [SuperadminSubscriptionController::class, 'show']);
            Route::put('/clients/{clientId}/subscription', [SuperadminSubscriptionController::class, 'update']);

            Route::get('/clients/{clientId}/invoices', [SuperadminInvoiceController::class, 'index']);
            Route::post('/clients/{clientId}/invoices', [SuperadminInvoiceController::class, 'store']);
            Route::get('/invoices/{invoiceId}', [SuperadminInvoiceController::class, 'show']);
            Route::put('/invoices/{invoiceId}', [SuperadminInvoiceController::class, 'update']);
            Route::post('/invoices/{invoiceId}/mark-sent', [SuperadminInvoiceController::class, 'markSent']);
            Route::post('/invoices/{invoiceId}/mark-paid', [SuperadminInvoiceController::class, 'markPaid']);
            Route::post('/invoices/{invoiceId}/void', [SuperadminInvoiceController::class, 'void']);
        });

        Route::get('/agenda-templates', [AgendaTemplateController::class, 'index']);
        Route::get('/agenda-templates/{templateId}', [AgendaTemplateController::class, 'show']);

        // Badge QR endpoints (public-ish — just needs auth)
        Route::get('/users/{userId}/badge-qr', [BadgeController::class, 'showQr'])
            ->name('badge.qr');
        Route::post('/users/{userId}/badge/regenerate', [BadgeController::class, 'regenerate']);
        Route::put('/users/{userId}/badge', [BadgeController::class, 'update']);

        Route::middleware('tenant.require')->group(function () {
            Route::get('/companies/options', [CompanyController::class, 'options']);
            Route::get('/companies', [CompanyController::class, 'index']);
            Route::post('/companies', [CompanyController::class, 'store']);
            Route::get('/companies/{companyId}', [CompanyController::class, 'show']);
            Route::put('/companies/{companyId}', [CompanyController::class, 'update']);
            Route::delete('/companies/{companyId}', [CompanyController::class, 'destroy']);

            // Event managers (event-scoped role EVENT_MANAGER)
            Route::get('/event-managers', [EventManagerController::class, 'index']);
            Route::post('/event-managers', [EventManagerController::class, 'store']);
            Route::get('/event-managers/{userId}', [EventManagerController::class, 'show']);
            Route::put('/event-managers/{userId}', [EventManagerController::class, 'update']);
            Route::delete('/event-managers/{userId}', [EventManagerController::class, 'destroy']);

            Route::get('/moderators', [ModeratorController::class, 'index']);
            Route::post('/moderators', [ModeratorController::class, 'store']);
            Route::get('/moderators/{userId}', [ModeratorController::class, 'show']);
            Route::put('/moderators/{userId}', [ModeratorController::class, 'update']);
            Route::delete('/moderators/{userId}', [ModeratorController::class, 'destroy']);

            Route::get('/audience', [AudienceController::class, 'index']);
            Route::get('/audience/export', [AudienceController::class, 'export']);
            Route::get('/audience/{id}', [AudienceController::class, 'show']);
            Route::post('/audience', [AudienceController::class, 'store']);
            Route::post('/audience/avatar/upload', [AudienceController::class, 'uploadAvatar']);
            Route::post('/audience/{id}/avatar', [AudienceController::class, 'uploadAvatar']);
            Route::put('/audience/{id}', [AudienceController::class, 'update']);
            Route::delete('/audience/{id}', [AudienceController::class, 'destroy']);
            Route::get('/audience/{id}/otp', [AdminController::class, 'latestOtp']);

            Route::get('/admin/api-logs', [AdminController::class, 'apiLogs']);

            // Tenant config — categories and other module-level settings
            Route::get('/admin/configs/{key}', [TenantConfigController::class, 'show']);
            Route::post('/admin/configs/{key}/items', [TenantConfigController::class, 'addItem']);
            Route::delete('/admin/configs/{key}/items', [TenantConfigController::class, 'removeItem']);

            // Global video feeds (tenant-wide, not event-scoped)
            Route::get('/global-video-feeds', [GlobalVideoFeedController::class, 'index']);
            Route::post('/global-video-feeds', [GlobalVideoFeedController::class, 'store']);
            Route::put('/global-video-feeds/{feedId}', [GlobalVideoFeedController::class, 'update']);
            Route::delete('/global-video-feeds/{feedId}', [GlobalVideoFeedController::class, 'destroy']);

            // Reader / Articles documents (tenant-wide)
            // upload-url must be registered before {documentId} to avoid route conflict
            Route::post('/reader-documents/upload-url', [ReaderDocumentController::class, 'uploadUrl']);
            Route::get('/reader-documents', [ReaderDocumentController::class, 'index']);
            Route::post('/reader-documents', [ReaderDocumentController::class, 'store']);
            Route::put('/reader-documents/{documentId}', [ReaderDocumentController::class, 'update']);
            Route::delete('/reader-documents/{documentId}', [ReaderDocumentController::class, 'destroy']);

            // Article analytics — admin reporting
            Route::get('/admin/articles/analytics/summary', [AdminArticleAnalyticsController::class, 'summary']);
            Route::get('/admin/articles/{articleId}/analytics', [AdminArticleAnalyticsController::class, 'articleSummary']);
            Route::get('/admin/articles/{articleId}/analytics/timeseries', [AdminArticleAnalyticsController::class, 'timeseries']);
            Route::get('/admin/content-analytics/summary', [AdminContentAnalyticsController::class, 'summary']);

            Route::get('/events/{eventId}/audience', [EventAudienceController::class, 'index']);
            Route::get('/events/{eventId}/audience/export', [EventAudienceController::class, 'export']);
            Route::post('/events/{eventId}/audience/assign', [EventAudienceController::class, 'assign']);
            Route::delete('/events/{eventId}/audience/bulk', [EventAudienceController::class, 'bulkRemove']);
            Route::patch('/events/{eventId}/audience/{userId}/roles', [EventAudienceController::class, 'updateRoles']);
            Route::delete('/events/{eventId}/audience/{userId}', [EventAudienceController::class, 'remove']);
            Route::post('/events/{eventId}/audience/import', [AudienceImportController::class, 'import']);
            Route::patch('/events/{eventId}/audience-visibility', [EventAudienceController::class, 'audienceVisibility']);
            Route::apiResource('events', EventController::class);
            Route::get('/events/{eventId}/dashboard', [EventController::class, 'dashboard']);

            Route::prefix('events/{eventId}')->group(function () {
                Route::get('/members', [EventMemberController::class, 'index']);
                Route::get('/members/{membershipId}', [EventMemberController::class, 'show']);
                Route::patch('/members/{membershipId}/role', [EventMemberController::class, 'updateRole']);
                Route::patch('/members/{membershipId}/status', [EventMemberController::class, 'updateStatus']);
                Route::delete('/members/{membershipId}', [EventMemberController::class, 'destroy']);

                Route::post('/invites', [InviteController::class, 'store']);
                Route::post('/invites/bulk', [InviteController::class, 'bulkStore']);
                Route::get('/invites', [InviteController::class, 'index']);
                Route::post('/invites/{inviteId}/cancel', [InviteController::class, 'cancel']);

                Route::get('/checkins', [EventCheckinController::class, 'index']);
                Route::post('/checkins', [EventCheckinController::class, 'store']);
                Route::delete('/checkins/{userId}', [EventCheckinController::class, 'destroy']);

                Route::get('/companies', [EventCompanyController::class, 'index'])->middleware('cache.public');
                Route::post('/companies', [EventCompanyController::class, 'store']);
                Route::delete('/companies/{companyId}', [EventCompanyController::class, 'destroy']);

                Route::get('/live-status', [EventLiveStatusController::class, 'snapshot']);
                Route::get('/stream', [EventStreamController::class, 'stream']);

                Route::get('/agenda', [EventAgendaController::class, 'index'])->middleware('cache.public');
                Route::post('/agenda', [EventAgendaController::class, 'store']);
                Route::put('/agenda/{agendaItemId}', [EventAgendaController::class, 'update']);
                Route::delete('/agenda/{agendaItemId}', [EventAgendaController::class, 'destroy']);
                Route::post('/agenda/apply-template', [EventAgendaController::class, 'applyTemplate']);

                Route::middleware('requires.module.new:surveys')->group(function () {
                    Route::get('/surveys', [EventSurveyController::class, 'index'])->middleware('cache.public');
                    Route::post('/surveys', [EventSurveyController::class, 'store']);
                    Route::get('/surveys/{surveyId}', [EventSurveyController::class, 'show']);
                    Route::put('/surveys/{surveyId}', [EventSurveyController::class, 'update']);
                    Route::delete('/surveys/{surveyId}', [EventSurveyController::class, 'destroy']);
                    Route::post('/surveys/{surveyId}/publish', [EventSurveyController::class, 'publish']);
                    Route::post('/surveys/{surveyId}/archive', [EventSurveyController::class, 'archive']);
                });

                Route::post('/test-data/surveys/reset', [TestDataController::class, 'resetSurveys']);
                Route::post('/test-data/polls/reset', [TestDataController::class, 'resetPolls']);
                Route::post('/test-data/reset-all', [TestDataController::class, 'resetAll']);

                Route::get('/polls', [EventPollController::class, 'index'])->middleware('cache.public');

                Route::middleware('requires.module.new:polls')->group(function () {
                    Route::post('/polls', [EventPollController::class, 'store']);
                    Route::get('/polls/{pollId}', [EventPollController::class, 'show']);
                    Route::put('/polls/{pollId}', [EventPollController::class, 'update']);
                    Route::delete('/polls/{pollId}', [EventPollController::class, 'destroy']);
                    Route::post('/polls/{pollId}/go-live', [EventPollController::class, 'goLive']);
                    Route::post('/polls/{pollId}/close', [EventPollController::class, 'close']);
                });

                Route::get('/video-feeds', [EventVideoFeedController::class, 'index'])->middleware('cache.public');
                Route::post('/video-feeds/{feedId}/view', [EventVideoFeedController::class, 'recordView']);

                Route::middleware('requires.module.new:video_feed')->group(function () {
                    Route::post('/video-feeds', [EventVideoFeedController::class, 'store']);
                    Route::put('/video-feeds/{feedId}', [EventVideoFeedController::class, 'update']);
                    Route::delete('/video-feeds/{feedId}', [EventVideoFeedController::class, 'destroy']);
                    Route::get('/video-feeds/{feedId}/stats', [EventVideoFeedController::class, 'stats']);
                });

                // Giveaways (admin / sponsor-rep)
                Route::get('/giveaways', [EventGiveawayController::class, 'index']);
                Route::post('/giveaways', [EventGiveawayController::class, 'store']);
                Route::get('/giveaways/{giveawayId}', [EventGiveawayController::class, 'show']);
                Route::put('/giveaways/{giveawayId}', [EventGiveawayController::class, 'update']);
                Route::delete('/giveaways/{giveawayId}', [EventGiveawayController::class, 'destroy']);
                Route::get('/giveaways/{giveawayId}/entries', [EventGiveawayController::class, 'entries']);
                Route::post('/giveaways/{giveawayId}/draw', [EventGiveawayController::class, 'draw']);
                Route::post('/giveaways/{giveawayId}/winners', [EventGiveawayController::class, 'winners']);

                // Lead scans & meetings (mobile + admin)
                Route::post('/lead-scans', [LeadScanController::class, 'scan']);
                Route::patch('/lead-scans/{scanId}', [EventReportingController::class, 'updateLeadScanNote']);
                Route::post('/meeting-requests', [LeadScanController::class, 'requestMeeting']);
                Route::patch('/meeting-requests/{meetingId}/respond', [LeadScanController::class, 'respondToMeeting']);

                // Survey submit (mobile)
                Route::post('/surveys/{surveyId}/submit', [SurveySubmitController::class, 'submit']);

                // Poll vote (mobile)
                Route::post('/polls/{pollId}/vote', [PollVoteController::class, 'vote']);

                // Admin reporting
                Route::get('/reports/lead-scans', [EventReportingController::class, 'leadScans']);
                Route::get('/reports/lead-scans/download', [EventReportingController::class, 'downloadLeadScans']);
                Route::get('/reports/lead-scans/users/{userId}', [EventReportingController::class, 'userActivity']);
                Route::get('/reports/lead-scans/users/{userId}/download', [EventReportingController::class, 'downloadUserActivity']);
                Route::post('/reports/lead-scans/users/{userId}/outreach', [EventReportingController::class, 'recordScannerOutreach']);
                Route::get('/reports/meetings', [EventReportingController::class, 'meetingRequests']);
                Route::patch('/reports/meetings/{meetingId}', [EventReportingController::class, 'updateMeetingStatus']);
                Route::get('/reports/meetings/download', [EventReportingController::class, 'downloadMeetings']);
                Route::get('/reports/surveys/{surveyId}', [EventReportingController::class, 'surveyReport']);
                Route::get('/reports/surveys/{surveyId}/download', [EventReportingController::class, 'downloadSurveyReport']);
                Route::get('/reports/polls/{pollId}', [EventReportingController::class, 'pollResults']);
                Route::get('/reports/polls/{pollId}/download', [EventReportingController::class, 'downloadPollResults']);
                Route::get('/reports/sponsor-reviews', [EventReportingController::class, 'sponsorReviews']);
                Route::get('/reports/sponsor-reviews/download', [EventReportingController::class, 'downloadSponsorReviews']);

                // Gamification
                Route::get('/gamification/leaderboard', [EventGamificationController::class, 'leaderboard'])->middleware('cache.public');
                Route::get('/gamification/rules', [EventGamificationController::class, 'getRules'])->middleware('cache.public');
                Route::put('/gamification/rules', [EventGamificationController::class, 'updateRules']);
                Route::get('/gamification/challenges', [EventGamificationController::class, 'getChallenges']);
                Route::post('/gamification/challenges', [EventGamificationController::class, 'createChallenge']);
                Route::put('/gamification/challenges/{challengeId}', [EventGamificationController::class, 'updateChallenge']);
                Route::delete('/gamification/challenges/{challengeId}', [EventGamificationController::class, 'deleteChallenge']);
                Route::post('/gamification/award', [EventGamificationController::class, 'awardPoints']);
                Route::post('/gamification/challenges/{challengeId}/complete', [EventGamificationController::class, 'completeChallenge']);
                Route::post('/gamification/challenges/{challengeId}/claim', [EventGamificationController::class, 'claimChallengePoints']);
                Route::post('/gamification/challenges/{challengeId}/mark-eligible', [EventGamificationController::class, 'markChallengeEligible']);
                Route::get('/gamification/my-points', [EventGamificationController::class, 'myPoints']);
            });
        });
    });
});

