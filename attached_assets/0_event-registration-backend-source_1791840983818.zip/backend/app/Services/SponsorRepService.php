<?php

namespace App\Services;

use App\Models\Sponsor;
use App\Models\User;

class SponsorRepService
{
    public function shouldBeSponsorRep(User $user, int $eventId): bool
    {
        $emailDomain = $this->extractDomain($user->email);
        if (!$emailDomain) {
            return false;
        }

        return Sponsor::withoutGlobalScopes()
            ->where('event_id', $eventId)
            ->where('is_active', true)
            ->where('sponsor_domain', $emailDomain)
            ->exists();
    }

    public function determineMembershipRole(User $user, int $eventId, string $defaultRole = 'attendee'): string
    {
        if ($this->shouldBeSponsorRep($user, $eventId)) {
            return 'sponsor_rep';
        }

        return $defaultRole;
    }

    protected function extractDomain(string $email): ?string
    {
        $parts = explode('@', $email);
        return count($parts) === 2 ? strtolower($parts[1]) : null;
    }
}
