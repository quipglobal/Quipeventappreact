<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\EventCheckin;
use App\Models\EventMembership;
use App\Services\BadgeService;
use App\Services\CredibilityService;
use App\Services\GamificationService;
use App\Services\SponsorRepService;
use Illuminate\Http\Request;

class EventJoinController extends Controller
{
    public function __construct(
        protected SponsorRepService $sponsorRepService,
        protected CredibilityService $credibilityService
    ) {}

    /**
     * POST /events/join-by-code  — accepts { "code": "ABC12" }
     * Alias of join(), mapping the `code` field to `event_code`.
     */
    public function joinByCode(Request $request)
    {
        $request->merge(['event_code' => $request->input('code', $request->input('event_code'))]);
        return $this->join($request);
    }

    public function join(Request $request)
    {
        // Accept either `code` (mobile-friendly) or `event_code` (legacy)
        $code = $request->input('event_code') ?? $request->input('code');

        if (empty($code)) {
            return response()->json([
                'success' => false,
                'error'   => ['code' => 'VALIDATION_ERROR', 'message' => 'An event code is required. Provide `code` or `event_code` in the request body.'],
            ], 422);
        }

        $event = Event::withoutGlobalScopes()
            ->where('event_code', $code)
            ->whereIn('status', ['published', 'active'])
            ->first();

        if (!$event) {
            return response()->json([
                'message' => 'Invalid event code or event is not available.',
            ], 404);
        }

        $user = $request->user();

        $existingMembership = EventMembership::where('event_id', $event->id)
            ->where('user_id', $user->id)
            ->first();

        if ($existingMembership) {
            // Even if already a member, ensure the user is checked in so they
            // appear in the audience list immediately (idempotent).
            $alreadyCheckedIn = EventCheckin::where('event_id', $event->id)
                ->where('user_id', $user->id)
                ->exists();

            if (!$alreadyCheckedIn) {
                try {
                    EventCheckin::create([
                        'event_id'              => $event->id,
                        'user_id'               => $user->id,
                        'checked_in_by_user_id' => $user->id,
                        'method'                => 'self',
                    ]);
                    $existingMembership->update([
                        'checked_in'    => true,
                        'checked_in_at' => now(),
                        'status'        => 'checked_in',
                    ]);
                    app(GamificationService::class)->awardPoints(
                        $event->id, $user->id, 'CHECK_IN', $event->id, 'event'
                    );
                } catch (\Throwable $e) {}
            }

            return response()->json([
                'success'         => true,
                'message'         => 'You have already joined this event.',
                'auto_checked_in' => !$alreadyCheckedIn,
                'role'            => $existingMembership->role,
                'event_id'        => $event->id,
                'membership_id'   => $existingMembership->id,
                'event'           => [
                    'id'     => $event->id,
                    'name'   => $event->name,
                    'code'   => $event->event_code,
                    'slug'   => $event->slug,
                    'status' => $event->status,
                ],
            ], 200);
        }

        if ($event->max_attendees) {
            $currentCount = EventMembership::where('event_id', $event->id)
                ->whereIn('status', ['registered', 'confirmed', 'checked_in'])
                ->count();

            if ($currentCount >= $event->max_attendees) {
                return response()->json([
                    'message' => 'This event has reached maximum capacity.',
                ], 422);
            }
        }

        $role = $this->sponsorRepService->determineMembershipRole($user, $event->id);

        $membership = EventMembership::create([
            'event_id' => $event->id,
            'user_id' => $user->id,
            'role' => $role,
            'status' => 'registered',
        ]);

        // Ensure user has a badge code (auto-generates if missing)
        if (!$user->badge_code) {
            try {
                app(\App\Services\BadgeService::class)->ensureBadgeCode($user);
                $user->refresh();
            } catch (\Exception $e) {}
        }

        $this->credibilityService->onEventJoin($user->id, $event->tenant_id);

        // Auto check-in the user immediately on join so they appear in the
        // audience list (checked_in_only mode) right after using the event code.
        $autoCheckedIn = false;
        try {
            EventCheckin::create([
                'event_id'              => $event->id,
                'user_id'               => $user->id,
                'checked_in_by_user_id' => $user->id,
                'method'                => 'self',
            ]);
            $autoCheckedIn = true;
            // Sync membership so admin reports and checked_in_only audience
            // lists reflect the check-in without a separate EventCheckin lookup.
            $membership->update([
                'checked_in'    => true,
                'checked_in_at' => now(),
                'status'        => 'checked_in',
            ]);
            // Award CHECK_IN gamification points
            app(GamificationService::class)->awardPoints(
                $event->id, $user->id, 'CHECK_IN', $event->id, 'event'
            );
        } catch (\Throwable $e) {
            // Non-fatal — join still succeeds even if auto check-in fails
        }

        $membership->load('event');

        $enabledModules = $event->enabled_modules ?? [];

        return response()->json([
            'success'          => true,
            'message'          => 'Joined successfully',
            'auto_checked_in'  => $autoCheckedIn,
            'role'             => $role,
            'event_id'         => $event->id,
            'membership_id'    => $membership->id,
            'event' => [
                'id'              => $event->id,
                'name'            => $event->name,
                'code'            => $event->event_code,
                'slug'            => $event->slug,
                'status'          => $event->status,
                'description'     => $event->description,
                'start_date'      => $event->start_date,
                'end_date'        => $event->end_date,
                'location'        => $event->location,
                'venue'           => $event->venue,
                'enabled_modules' => $enabledModules,
            ],
            'badge_code'  => $user->badge_code,
            'qr_code_url' => route('badge.qr', ['userId' => $user->id]),
        ], 201);
    }

    public function myRole(Request $request, int $eventId)
    {
        $user = $request->user();

        $membership = EventMembership::where('event_id', $eventId)
            ->where('user_id', $user->id)
            ->first();

        if (!$membership) {
            return response()->json([
                'message' => 'You are not a member of this event.',
            ], 404);
        }

        return response()->json([
            'event_id' => $eventId,
            'role' => $membership->role,
            'status' => $membership->status,
            'joined_at' => $membership->created_at,
        ]);
    }
}
