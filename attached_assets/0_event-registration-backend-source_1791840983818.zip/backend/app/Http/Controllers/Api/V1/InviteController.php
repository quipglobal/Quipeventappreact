<?php

namespace App\Http\Controllers\Api\V1;

use App\Http\Controllers\Controller;
use App\Models\Event;
use App\Models\Invite;
use App\Models\EventMembership;
use App\Models\User;
use App\Services\CredibilityService;
use App\Services\SponsorRepService;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Carbon\Carbon;

class InviteController extends Controller
{
    public function __construct(
        protected SponsorRepService $sponsorRepService,
        protected CredibilityService $credibilityService
    ) {}

    public function store(Request $request, int $eventId)
    {
        $validated = $request->validate([
            'email' => 'required|email',
            'invite_type' => 'required|in:attendee,sponsor_rep,speaker,staff',
            'message' => 'nullable|string|max:1000',
        ]);

        $event = Event::findOrFail($eventId);

        $existingInvite = Invite::where('event_id', $event->id)
            ->where('email', $validated['email'])
            ->where('status', 'pending')
            ->where('expires_at', '>', now())
            ->first();

        if ($existingInvite) {
            return response()->json([
                'message' => 'An active invite already exists for this email.',
                'invite' => $existingInvite,
            ], 422);
        }

        $token = Str::random(64);

        $invite = Invite::create([
            'tenant_id' => $event->tenant_id,
            'event_id' => $event->id,
            'invited_by' => $request->user()->id,
            'email' => $validated['email'],
            'invite_type' => $validated['invite_type'],
            'token' => $token,
            'status' => 'pending',
            'message' => $validated['message'] ?? null,
            'expires_at' => Carbon::now()->addDays(7),
        ]);

        $this->sendInviteEmail($invite, $event);

        return response()->json([
            'message' => 'Invite sent successfully.',
            'invite' => $invite,
        ], 201);
    }

    public function bulkStore(Request $request, int $eventId)
    {
        $validated = $request->validate([
            'invites' => 'required|array|min:1|max:50',
            'invites.*.email' => 'required|email',
            'invites.*.invite_type' => 'required|in:attendee,sponsor_rep,speaker,staff',
            'invites.*.message' => 'nullable|string|max:1000',
        ]);

        $event = Event::findOrFail($eventId);
        $results = [];

        foreach ($validated['invites'] as $inviteData) {
            $existingInvite = Invite::where('event_id', $event->id)
                ->where('email', $inviteData['email'])
                ->where('status', 'pending')
                ->where('expires_at', '>', now())
                ->first();

            if ($existingInvite) {
                $results[] = [
                    'email' => $inviteData['email'],
                    'status' => 'skipped',
                    'reason' => 'Active invite exists',
                ];
                continue;
            }

            $invite = Invite::create([
                'tenant_id' => $event->tenant_id,
                'event_id' => $event->id,
                'invited_by' => $request->user()->id,
                'email' => $inviteData['email'],
                'invite_type' => $inviteData['invite_type'],
                'token' => Str::random(64),
                'status' => 'pending',
                'message' => $inviteData['message'] ?? null,
                'expires_at' => Carbon::now()->addDays(7),
            ]);

            $this->sendInviteEmail($invite, $event);

            $results[] = [
                'email' => $inviteData['email'],
                'status' => 'sent',
                'invite_id' => $invite->id,
            ];
        }

        return response()->json([
            'message' => 'Bulk invites processed.',
            'results' => $results,
        ], 201);
    }

    public function index(Request $request, int $eventId)
    {
        $event = Event::findOrFail($eventId);

        $query = Invite::where('event_id', $event->id);

        if ($request->has('status')) {
            $query->where('status', $request->status);
        }

        $invites = $query->with('invitedBy:id,name,email')
            ->orderBy('created_at', 'desc')
            ->paginate($request->get('per_page', 20));

        return response()->json($invites);
    }

    public function cancel(int $eventId, int $inviteId)
    {
        $invite = Invite::where('event_id', $eventId)
            ->where('id', $inviteId)
            ->where('status', 'pending')
            ->firstOrFail();

        $invite->update(['status' => 'cancelled']);

        return response()->json([
            'message' => 'Invite cancelled.',
            'invite' => $invite,
        ]);
    }

    public function accept(Request $request)
    {
        $validated = $request->validate([
            'token' => 'required|string',
        ]);

        $invite = Invite::withoutGlobalScopes()
            ->where('token', $validated['token'])
            ->where('status', 'pending')
            ->first();

        if (!$invite) {
            return response()->json([
                'message' => 'Invalid or already used invite.',
            ], 404);
        }

        if ($invite->isExpired()) {
            $invite->update(['status' => 'expired']);
            return response()->json([
                'message' => 'This invite has expired.',
            ], 422);
        }

        $user = $request->user();

        $existingMembership = EventMembership::where('event_id', $invite->event_id)
            ->where('user_id', $user->id)
            ->first();

        if ($existingMembership) {
            $invite->update([
                'status' => 'accepted',
                'accepted_at' => now(),
                'accepted_by_user_id' => $user->id,
            ]);

            return response()->json([
                'message' => 'You are already a member of this event.',
                'membership' => $existingMembership->load('event'),
            ]);
        }

        $role = $invite->invite_type;
        if ($role === 'attendee') {
            $role = $this->sponsorRepService->determineMembershipRole($user, $invite->event_id);
        }

        $membership = EventMembership::create([
            'event_id' => $invite->event_id,
            'user_id' => $user->id,
            'role' => $role,
            'status' => 'confirmed',
        ]);

        $invite->update([
            'status' => 'accepted',
            'accepted_at' => now(),
            'accepted_by_user_id' => $user->id,
        ]);

        $event = Event::withoutGlobalScopes()->find($invite->event_id);
        $this->credibilityService->onInviteAccepted($user->id, $event->tenant_id);

        $membership->load('event');

        return response()->json([
            'message' => 'Invite accepted. You have joined the event.',
            'membership' => $membership,
            'role' => $role,
        ], 201);
    }

    protected function sendInviteEmail(Invite $invite, Event $event): void
    {
        \App\Jobs\SendInviteEmailJob::dispatch($invite, $event);
    }

}
