<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use App\Models\Scopes\TenantScope;

class Event extends Model
{
    use HasFactory, SoftDeletes;

    protected $fillable = [
        'tenant_id',
        'name',
        'description',
        'slug',
        'event_code',
        'banner_url',
        'location',
        'venue',
        'latitude',
        'longitude',
        'category',
        'start_date',
        'end_date',
        'timezone',
        'status',
        'registration_url',
        'max_attendees',
        'settings',
        'enabled_modules',
        'plan_tier',
    ];

    protected $casts = [
        'start_date' => 'datetime',
        'end_date' => 'datetime',
        'settings' => 'array',
        'enabled_modules' => 'array',
    ];

    protected static function booted(): void
    {
        static::addGlobalScope(new TenantScope);
    }

    public function tenant(): BelongsTo
    {
        return $this->belongsTo(Tenant::class);
    }

    public function memberships(): HasMany
    {
        return $this->hasMany(EventMembership::class);
    }

    public function checkins(): HasMany
    {
        return $this->hasMany(EventCheckin::class);
    }

    public function eventCompanies(): HasMany
    {
        return $this->hasMany(EventCompany::class);
    }

    public function surveys(): HasMany
    {
        return $this->hasMany(EventSurvey::class);
    }

    public function polls(): HasMany
    {
        return $this->hasMany(EventPoll::class);
    }

    public function agendaItems(): HasMany
    {
        return $this->hasMany(AgendaItem::class);
    }

    public function isPremium(): bool
    {
        $service = app(\App\Services\NewEntitlementService::class);
        $sub = $service->getCurrentSubscription($this->tenant_id);
        return $sub && $sub->plan && strtoupper($sub->plan->name) === 'PREMIUM';
    }

    public function clientHasModule(string $moduleKey): bool
    {
        return app(\App\Services\NewEntitlementService::class)->hasModule($this->tenant_id, $moduleKey);
    }
}
