<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class EventMembership extends Model
{
    use HasFactory;

    protected $fillable = [
        'event_id',
        'user_id',
        'role',
        'status',
        'badge_code',
        'checked_in',
        'checked_in_at',
        'joined_at',
        'metadata',
        'networking_opt_in',
    ];

    protected $casts = [
        'checked_in'        => 'boolean',
        'checked_in_at'     => 'datetime',
        'joined_at'         => 'datetime',
        'metadata'          => 'array',
        'networking_opt_in' => 'boolean',
    ];

    public function event(): BelongsTo
    {
        return $this->belongsTo(Event::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function eventRoles(): HasMany
    {
        return $this->hasMany(EventRole::class, 'event_membership_id');
    }

    public function getRoleNamesAttribute(): array
    {
        return $this->eventRoles->pluck('role')->toArray();
    }
}
