<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('events', function (Blueprint $table) {
            $table->id();
            $table->foreignId('tenant_id')->constrained('tenants')->cascadeOnDelete();
            $table->string('name');
            $table->text('description')->nullable();
            $table->string('slug')->nullable();
            $table->string('event_code')->nullable();
            $table->string('banner_url')->nullable();
            $table->string('location')->nullable();
            $table->string('venue')->nullable();
            $table->string('category')->nullable();
            $table->timestamp('start_date')->nullable();
            $table->timestamp('end_date')->nullable();
            $table->string('timezone')->default('UTC');
            $table->string('status')->default('draft');
            $table->string('registration_url')->nullable();
            $table->integer('max_attendees')->nullable();
            $table->json('settings')->nullable();
            $table->json('enabled_modules')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['tenant_id', 'status']);
            $table->index('event_code');
        });

        Schema::create('event_memberships', function (Blueprint $table) {
            $table->id();
            $table->foreignId('event_id')->constrained('events')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();
            $table->string('role')->default('attendee');
            $table->string('status')->default('registered');
            $table->boolean('checked_in')->default(false);
            $table->timestamp('checked_in_at')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->unique(['event_id', 'user_id', 'role']);
            $table->index(['event_id', 'role']);
            $table->index(['user_id']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('event_memberships');
        Schema::dropIfExists('events');
    }
};
