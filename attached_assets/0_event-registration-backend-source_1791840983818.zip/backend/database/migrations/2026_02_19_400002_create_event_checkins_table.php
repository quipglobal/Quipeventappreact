<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('event_checkins', function (Blueprint $table) {
            $table->id();
            $table->foreignId('event_id')->constrained('events')->onDelete('cascade');
            $table->foreignId('user_id')->constrained('users')->onDelete('cascade');
            $table->foreignId('checked_in_by_user_id')->constrained('users')->onDelete('cascade');
            $table->string('method')->default('manual');
            $table->integer('round')->default(1);
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->unique(['event_id', 'user_id', 'round']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('event_checkins');
    }
};
