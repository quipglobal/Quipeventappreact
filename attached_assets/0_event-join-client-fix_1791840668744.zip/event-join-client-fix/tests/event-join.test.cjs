// Run after installing the repository's dev dependencies:
// node --test tests/event-join.test.cjs
const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');
const ts = require('typescript');
const root = path.resolve(__dirname, '..');

function evaluate(source, mocks = {}, globals = {}) {
  const result = ts.transpileModule(source, {
    compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020, jsx: ts.JsxEmit.React },
    reportDiagnostics: true,
  });
  assert.equal((result.diagnostics ?? []).filter(d => d.category === ts.DiagnosticCategory.Error).length, 0);
  const module = { exports: {} };
  vm.runInNewContext(result.outputText, {
    module, exports: module.exports, console, Error, __DEV__: false,
    require: name => {
      assert.ok(name in mocks, `Unexpected dependency: ${name}`);
      return mocks[name];
    },
    ...globals,
  });
  return module.exports;
}

function client(kind, response, access = { success: true, data: { is_member: true } }, detailId = '42') {
  const calls = [];
  const get = async url => {
    calls.push({ url, method: 'GET' });
    if (url.endsWith('/access')) return access;
    return { success: true, data: { id: detailId, name: 'Selected event', event_code: 'ABC12' } };
  };
  const post = async (url, body) => {
    calls.push({ url, method: 'POST', body });
    return response;
  };
  const file = kind === 'web' ? 'src/app/api/eventsClient.ts' : 'mobile/lib/api/events.ts';
  const mocks = kind === 'web'
    ? { './client': { apiPost: post, apiGet: get, apiPut: post } }
    : {
      '@/lib/apiClient': { request: (url, options) => options?.method === 'POST'
        ? post(url, JSON.parse(options.body)) : get(url) },
      '@/lib/eventStore': { getEventId: () => '' },
    };
  const api = evaluate(fs.readFileSync(path.join(root, file), 'utf8'), mocks);
  return { join: kind === 'web' ? api.joinEventWithCode : api.joinByCode, api, calls };
}

for (const kind of ['web', 'mobile']) {
  test(`${kind}: sends normalized key and selected event_id`, async () => {
    const c = client(kind, { success: true, data: { event: { id: 42, name: 'Selected event' }, membership_id: '8' } });
    const res = await c.join(' abc12 ', '42');
    assert.equal(res.success, true);
    assert.equal(kind === 'web' ? res.data.eventId : res.data.id, '42');
    assert.equal(res.data.membershipId, 8);
    assert.equal(JSON.stringify(c.calls[0].body), JSON.stringify({ event_code: 'ABC12', code: 'ABC12', event_id: '42' }));
    assert.equal(c.calls[0].url, '/api/v1/events/join');
  });

  for (const [label, data] of [
    ['inline event', { event: { id: 3279 } }],
    ['snake-case ID', { event_id: 3279 }],
    ['camel-case ID', { eventId: '3279' }],
    ['nested event', { data: { event: { id: 3279 } } }],
    ['nested snake-case ID', { data: { event_id: 3279 } }],
    ['contradictory IDs', { event: { id: 42 }, event_id: 3279 }],
    ['contradictory envelope', { event_id: 3279, data: { event_id: 42 } }],
  ]) {
    test(`${kind}: rejects wrong event in ${label} without follow-up requests`, async () => {
      const c = client(kind, { success: true, data });
      const res = await c.join('ABC12', '42');
      assert.equal(res.success, false);
      assert.equal(res.error.code, 'EVENT_JOIN_MISMATCH');
      assert.equal(c.calls.length, 1);
    });
  }

  test(`${kind}: accepts matching nested response`, async () => {
    const c = client(kind, { success: true, data: { data: { event: { id: '42', name: 'Selected' } } } });
    assert.equal((await c.join('ABC12', '42')).success, true);
  });

  for (const response of [
    { success: true, data: { id: 999, message: 'Joined' } },
    { success: false, error: { code: '409', message: 'Already joined' } },
  ]) {
    const label = response.success ? 'missing event ID' : '409 conflict';
    test(`${kind}: ${label} requires selected-event membership proof`, async () => {
      const c = client(kind, response);
      const res = await c.join('ABC12', '42');
      assert.equal(res.success, true);
      assert.equal(kind === 'web' ? res.data.eventId : res.data.id, '42');
      assert.ok(c.calls.some(call => call.url === '/api/v1/events/42/access'));
    });

    for (const access of [
      { success: true, data: { is_member: false } },
      { success: true, data: { is_member: 'false' } },
      { success: false, error: { message: 'Network failure' } },
    ]) {
      test(`${kind}: ${label} fails closed without membership proof (${String(access.data?.is_member ?? 'unavailable')})`, async () => {
        const c = client(kind, response, access);
        const res = await c.join('ABC12', '42');
        assert.equal(res.success, false);
        assert.equal(res.error.code, 'EVENT_JOIN_UNCONFIRMED');
        assert.equal(c.calls.length, 2);
      });
    }
  }

  test(`${kind}: preserves standalone code-entry payload`, async () => {
    const c = client(kind, { success: true, data: { event: { id: 3279, name: 'Code-only event' } } });
    const res = await c.join('ABC12');
    assert.equal(res.success, true);
    assert.equal(Object.hasOwn(c.calls[0].body, 'event_id'), false);
  });

  test(`${kind}: validation failure does not trigger membership lookups`, async () => {
    const c = client(kind, { success: false, error: { code: '422', message: 'Invalid key' } });
    const res = await c.join('BAD', '42');
    assert.equal(res.success, false);
    assert.equal(c.calls.length, 1);
  });
}

test('mobile: rejects a wrong event fetched from a matching join response', async () => {
  const c = client('mobile', { success: true, data: { event_id: 42 } }, undefined, '3279');
  const res = await c.join('ABC12', '42');
  assert.equal(res.error.code, 'EVENT_JOIN_MISMATCH');
});

// Execute the actual UI handler expressions with mocked dependencies.
function handler(file, name, globals) {
  const source = fs.readFileSync(path.join(root, file), 'utf8');
  const ast = ts.createSourceFile(file, source, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);
  let initializer;
  function visit(node) {
    if (ts.isVariableDeclaration(node) && node.name.getText(ast) === name) initializer = node.initializer.getText(ast);
    ts.forEachChild(node, visit);
  }
  visit(ast);
  assert.ok(initializer, `Missing handler ${name}`);
  return evaluate(`module.exports = ${initializer};`, {}, globals);
}

test('web: selected-event gate surfaces mismatch and never enters or checks in', async () => {
  const calls = [];
  const fn = handler('src/app/components/EventJoinPage.tsx', 'handleJoinWithKey', {
    gateEvent: { id: '42' }, eventKey: 'ABC12',
    setKeyError: message => calls.push(['error', message]),
    setIsJoiningEvent: () => {},
    joinEventWithCode: async (...args) => {
      assert.equal(args[1], '42');
      return { success: false, error: { code: 'EVENT_JOIN_MISMATCH', message: 'Different event' } };
    },
    selfCheckInApi: () => { throw Error('Unexpected check-in'); },
    enterEvent: () => { throw Error('Unexpected navigation'); },
    setGateEvent: () => { throw Error('Unexpected gate dismissal'); },
  });
  await fn();
  assert.ok(calls.some(call => call[1] === 'Different event'));
});

test('web: silent join sends selected ID and keeps the gate on mismatch', async () => {
  const gates = [];
  const fn = handler('src/app/components/EventJoinPage.tsx', 'handleEventCardClick', {
    setCheckingEventId: () => {},
    checkEventAccess: async () => ({ success: false }),
    joinEventWithCode: async (...args) => {
      assert.equal(args[1], '42');
      return { success: false, error: { code: 'EVENT_JOIN_MISMATCH' } };
    },
    enterEvent: () => { throw Error('Unexpected navigation'); },
    selfCheckInApi: () => { throw Error('Unexpected check-in'); },
    setGateEvent: event => gates.push(event.id), setEventKey: () => {}, setKeyError: () => {},
  });
  await fn({ id: '42', code: 'ABC12' });
  assert.deepEqual(gates, ['42']);
});

test('mobile: selected popup never converts API error into local success', async () => {
  const alerts = [];
  const fn = handler('mobile/app/events.tsx', 'handleJoin', {
    useCallback: fn => fn,
    selectedEvent: { id: '42', name: 'Selected' },
    allEvents: [{ id: '42', code: 'ABC12', name: 'Selected' }],
    findAndJoin: (input, options) => {
      assert.equal(input.eventId, '42');
      options.onError(new Error('Different event'));
    },
    Alert: { alert: (...args) => alerts.push(args) },
    setCurrentEventId: () => { throw Error('Unexpected event switch'); },
    refreshEventRole: () => { throw Error('Unexpected role refresh'); },
    saveJoinedEvent: () => { throw Error('Unexpected local membership/check-in'); },
    goToFeed: () => { throw Error('Unexpected navigation'); },
    setSelectedEvent: () => { throw Error('Unexpected dismissal'); },
  });
  await fn('ABC12');
  assert.equal(alerts[0][1], 'Different event');
});

test('mobile: dashboard sends selected ID through the real join mutation', async () => {
  const api = evaluate(fs.readFileSync(path.join(root, 'mobile/hooks/useEvents.ts'), 'utf8'), {
    '@tanstack/react-query': { useMutation: options => options },
    '@/hooks/useAuthedQuery': { useAuthedQuery: () => {} },
    '@/lib/api/events': {
      joinByCode: async (code, eventId) => {
        assert.equal(code, 'ABC12');
        assert.equal(eventId, '42');
        return { success: false, error: { message: 'Different event' } };
      },
    },
    '@/lib/api/users': { getUserPoints: () => {} },
  });
  await assert.rejects(api.useJoinEvent().mutationFn({ code: 'ABC12', eventId: '42' }), /Different event/);
  const fn = handler('mobile/app/event-dashboard.tsx', 'handlePopupJoin', {
    popupCode: 'ABC12', selectedEvent: { id: '42' },
    joinEvent: (input, options) => {
      assert.equal(input.eventId, '42');
      options.onError(new Error('Different event'));
    },
    Alert: { alert: () => {} },
  });
  fn();
});

test('modified TypeScript and TSX files transpile without syntax errors', () => {
  for (const file of [
    'src/app/api/eventsClient.ts', 'src/app/components/EventJoinPage.tsx',
    'mobile/lib/api/events.ts', 'mobile/app/events.tsx',
    'mobile/hooks/useEvents.ts', 'mobile/app/event-dashboard.tsx',
  ]) {
    evaluateSyntax(file);
  }
  function evaluateSyntax(file) {
    const result = ts.transpileModule(fs.readFileSync(path.join(root, file), 'utf8'), {
      fileName: file,
      compilerOptions: { module: ts.ModuleKind.CommonJS, target: ts.ScriptTarget.ES2020, jsx: ts.JsxEmit.React },
      reportDiagnostics: true,
    });
    assert.equal((result.diagnostics ?? []).filter(d => d.category === ts.DiagnosticCategory.Error).length, 0, file);
  }
});

test('API helpers pass strict type checking with typed transport contracts', () => {
  const apiResponse = `export interface ApiResponse<T> {
    success: boolean; data?: T; error?: { code: string; message: string; detail?: string };
  }`;
  const virtual = {
    '/virtual/apiClient.d.ts': `${apiResponse}
      export type AuthUser = Record<string, unknown>;
      export function request<T>(url: string, options?: RequestInit): Promise<ApiResponse<T>>;`,
    '/virtual/eventStore.d.ts': 'export function getEventId(): string | null;',
    '/virtual/client.d.ts': `export interface ApiEnvelope<T> {
      success: boolean; data?: T; error?: { code?: string; message: string };
    }
    export function apiGet<T>(url: string, headers?: Record<string, string>): Promise<ApiEnvelope<T>>;
    export function apiPost<T>(url: string, body: unknown, headers?: Record<string, string>): Promise<ApiEnvelope<T>>;
    export function apiPut<T>(url: string, body: unknown, headers?: Record<string, string>): Promise<ApiEnvelope<T>>;`,
    '/virtual/globals.d.ts': 'declare const __DEV__: boolean;',
  };
  const options = {
    noEmit: true, strict: true, skipLibCheck: true, types: [],
    target: ts.ScriptTarget.ES2020, module: ts.ModuleKind.CommonJS,
  };
  const host = ts.createCompilerHost(options);
  const original = host.getSourceFile.bind(host);
  host.getSourceFile = (file, version, ...args) => file in virtual
    ? ts.createSourceFile(file, virtual[file], version, true)
    : original(file, version, ...args);
  host.resolveModuleNames = names => names.map(name => ({
    resolvedFileName: {
      '@/lib/apiClient': '/virtual/apiClient.d.ts',
      '@/lib/eventStore': '/virtual/eventStore.d.ts',
      '@/lib/api/types': path.join(root, 'mobile/lib/api/types.ts'),
      './client': '/virtual/client.d.ts',
    }[name],
    extension: name === '@/lib/api/types' ? ts.Extension.Ts : ts.Extension.Dts,
  }));
  const program = ts.createProgram([
    path.join(root, 'mobile/lib/api/events.ts'),
    path.join(root, 'src/app/api/eventsClient.ts'),
    '/virtual/globals.d.ts',
  ], options, host);
  const diagnostics = ts.getPreEmitDiagnostics(program);
  assert.equal(diagnostics.length, 0, ts.formatDiagnosticsWithColorAndContext(diagnostics, {
    getCurrentDirectory: () => root, getCanonicalFileName: file => file, getNewLine: () => '\n',
  }));
});
