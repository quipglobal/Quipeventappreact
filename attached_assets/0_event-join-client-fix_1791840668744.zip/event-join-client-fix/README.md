# Selected-event registration fix

Target repository: https://github.com/quipglobal/Quipeventappreact
Base branch: main
Base revision: f93cbfebbc9c0cec104990810193292780132feb

This bundle contains a Git patch, the changed source files, a design note, and regression tests. It contains no `.env` files, credentials, backend source, or dependencies. Nothing has been pushed to GitHub or deployed.

## Apply the patch

Unzip this bundle into a separate directory, not directly over your repository.
From a clean checkout of the target repository:

```sh
git apply --check /path/to/event-join-client-fix/event-join-client-fix.patch
git apply /path/to/event-join-client-fix/event-join-client-fix.patch
node --test tests/event-join.test.cjs
```

The test command requires TypeScript from the repository's existing dev dependencies.
If the patch check fails, reconcile the changes with your current branch rather than overwriting files.

## Behavior

- Both web and Expo mobile clients send `event_id` alongside `event_code` and `code` when an event has been selected.
- Every explicit returned event ID is checked against the selection before local membership, points, self-check-in, or navigation.
- Missing event IDs and already-member conflicts require a successful membership check for the selected event.
- Selected-event errors cannot fall back to a locally successful join.
- The mobile dashboard now uses the real join endpoint instead of a local event lookup.
- Standalone code-entry flows remain compatible when no event has been selected.

Example selected-event payload:

```json
{ "event_id": "42", "event_code": "ABC12", "code": "ABC12" }
```

## Verification

45 regression checks passed using mocked transports and actual UI handler expressions. They include response IDs pointing to 3279 instead of selected event 42, nested/contradictory response IDs, missing IDs, conflicts, membership-check failures, and legacy code-entry behavior.

All modified TypeScript/TSX files passed syntax transpilation. The API helpers passed strict type checking against typed transport contracts.

Full web/Expo builds, rendered signed-in screens, and live hosted-backend registration were not verified. The current Replit preview is a separate application and does not run this patch.

## Required backend change

The separately hosted Laravel join handler must validate that the submitted key belongs to the submitted event ID and tenant **before** creating audience membership or automatic check-in.

Client response checks cannot prevent or undo incorrect membership already created by a server that ignores `event_id`. Require a stable event identity in success responses; reject an ID/key mismatch without side effects.
