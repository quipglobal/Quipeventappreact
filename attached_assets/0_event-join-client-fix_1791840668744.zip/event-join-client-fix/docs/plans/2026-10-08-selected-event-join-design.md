# Selected-event joins

Approved scope: patch the React web and Expo mobile clients, not the separately hosted Laravel backend. Do not push to GitHub.

Send the selected event ID as `event_id` alongside `event_code` and `code`. Keep standalone code-entry calls compatible by making the ID optional.

Inspect all explicit event IDs in join responses. Reject a different ID before local membership, points, self-check-in, or navigation. When no event ID is returned (including an already-member conflict), require a successful membership check for the selected event. Never interpret a generic top-level `id` as proof of event identity: it may identify membership.

Selected-event API failures must not fall back to local success. Route the dashboard's local-only join mutation through the same guarded API.

Implementation checklist:
- Extend and guard web and mobile join helpers.
- Pass selected IDs from gates, silent joins, and dashboard joins.
- Prevent UI fallbacks from bypassing selected-event errors.
- Add mocked regression tests for matching/mismatching IDs, missing IDs, conflicts, code-only compatibility, and caller wiring.
- Deliver a patch and changed-source archive with application instructions.

Server requirement: validate the key against the selected event and tenant before creating audience membership. Client checks cannot undo server-side side effects.
